//
//  AltAppIconsViewController.swift
//  AltStore
//
//  Created by Riley Testut on 2/14/24.
//  Copyright © 2024 Riley Testut. All rights reserved.
//

@preconcurrency import UIKit
import SwiftUI

import SideSign

extension UIApplication
{
    static let didChangeAppIconNotification = Notification.Name("io.sidestore.AppManager.didChangeAppIcon")
}

private final class AltIcon: Decodable
{
    static let defaultName: String = "Original"
    
    var name: String
    var imageName: String
    var iconName: String
    
    private enum CodingKeys: String, CodingKey
    {
        case name
        case imageName
        case iconName
    }
    
    required init(from decoder: Decoder) throws
    {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.name = try container.decode(String.self, forKey: .name)
        self.imageName = try container.decode(String.self, forKey: .imageName)
        self.iconName = try container.decode(String.self, forKey: .iconName)
    }
}

extension AltAppIconsViewController
{
    private enum Section: String, CaseIterable, Decodable, CodingKeyRepresentable
    {
        case classic
        case modern
//        case gradient
//        case recessed
        
        var localizedName: String {
            switch self
            {
            case .classic: return NSLocalizedString("经典", comment: "")
            case .modern: return NSLocalizedString("现代", comment: "")
//            case .gradient: return NSLocalizedString("渐变", comment: "")
//            case .recessed: return NSLocalizedString("内嵌", comment: "")
            }
        }
    }
}

class AltAppIconsViewController: UICollectionViewController
{
    private lazy var dataSource = self.makeDataSource()
    
    private var iconsBySection = [Section: [AltIcon]]()
    
    private var headerRegistration: UICollectionView.SupplementaryRegistration<UICollectionViewListCell>!
    
    private var currentAlternateIconName: String? = UIApplication.shared.alternateIconName
        
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.title = NSLocalizedString("更换应用图标", comment: "")
        
        let collectionViewLayout = self.makeLayout()
        self.collectionView.collectionViewLayout = collectionViewLayout
        
        self.collectionView.backgroundColor = UIColor(resource: .settingsBackground)
        
        do
        {
            let fileURL = Bundle.main.url(forResource: "AltIcons", withExtension: "plist")!
            let data = try Data(contentsOf: fileURL)
            
            let icons = try PropertyListDecoder().decode([Section: [AltIcon]].self, from: data)
            self.iconsBySection = icons
        }
        catch
        {
            debugLog("Failed to load alternate icons. \(error.localizedDescription)")
        }
        
        self.dataSource.proxy = self
        self.collectionView.dataSource = self.dataSource
        self.dataSource.contentView = self.collectionView
        
        self.collectionView.register(UICollectionViewListCell.self, forCellWithReuseIdentifier: CellContentGenericCellIdentifier)
        self.collectionView.register(UICollectionViewListCell.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: UICollectionView.elementKindSectionHeader)
                
        self.headerRegistration = UICollectionView.SupplementaryRegistration<UICollectionViewListCell>(elementKind: UICollectionView.elementKindSectionHeader) { (headerView, elementKind, indexPath) in
            let section = Section.allCases[indexPath.section]
            
            let font = UIFont(descriptor: UIFontDescriptor.preferredFontDescriptor(withTextStyle: .body).bolded(), size: 0.0)
            
            var configuration = UIListContentConfiguration.cell()
            configuration.text = section.localizedName
            configuration.textProperties.font = font
            configuration.textProperties.color = .white.withAlphaComponent(0.8)
            headerView.contentConfiguration = configuration
            
            headerView.backgroundConfiguration = .clear()
        }
    }
}

private extension AltAppIconsViewController
{
    func makeLayout() -> UICollectionViewCompositionalLayout
    {
        #if !os(tvOS)
        var configuration = UICollectionLayoutListConfiguration(appearance: .insetGrouped)
        configuration.showsSeparators = true
        #else
        var configuration = UICollectionLayoutListConfiguration(appearance: .grouped)
        #endif
        configuration.backgroundColor = .clear
        configuration.headerMode = .supplementary
                
        let layout = UICollectionViewCompositionalLayout.list(using: configuration)
        return layout
    }
    
    func makeDataSource() -> CompositeCollectionViewDataSource<AltIcon>
    {
        let dataSources = Section.allCases.compactMap { self.iconsBySection[$0] }.filter { !$0.isEmpty }.map { icons in
            let dataSource = ArrayCollectionViewDataSource<AltIcon>(items: icons)
            return dataSource
        }
        
        let dataSource = CompositeCollectionViewDataSource<AltIcon>(dataSources: dataSources)
        dataSource.cellConfigurationHandler = { [weak self] cell, icon, indexPath in
            let cell = cell as! UICollectionViewListCell
            
            let imageWidth = 44.0
            let font = UIFont(descriptor: UIFontDescriptor.preferredFontDescriptor(withTextStyle: .body).bolded(), size: 0.0)
            
            var config = cell.defaultContentConfiguration()
            config.text = icon.name
            config.textProperties.font = font
            config.textProperties.color = .label

            let image = UIImage(named: icon.imageName)
            config.image = image
            config.imageProperties.maximumSize = CGSize(width: imageWidth, height: imageWidth)
            config.imageProperties.cornerRadius = imageWidth / 5.0 // Copied from AppIconImageView
            
            cell.contentConfiguration = config

            let activeIconName = self?.currentAlternateIconName
            let isSelected = (activeIconName == icon.iconName) || (activeIconName == nil && icon.name == AltIcon.defaultName)

            if isSelected
            {
                cell.accessories = [.checkmark(options: .init(tintColor: .white))]
            }
            else
            {
                cell.accessories = []
            }
            
            var backgroundConfiguration = UIBackgroundConfiguration.listPlainCell()
            backgroundConfiguration.backgroundColorTransformer = UIConfigurationColorTransformer { [weak cell] c in
                if let state = cell?.configurationState, state.isHighlighted 
                {
                    // Highlighted, so use darker white for background.
                    return .white.withAlphaComponent(0.4)
                }
                
                return .white.withAlphaComponent(0.25)
            }
            cell.backgroundConfiguration = backgroundConfiguration
                        
            // Ensure text is legible on green background.
            cell.overrideUserInterfaceStyle = .dark
        }
        
        return dataSource
    }
}

extension AltAppIconsViewController
{
    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView
    {
        let headerView = self.collectionView.dequeueConfiguredReusableSupplementary(using: self.headerRegistration, for: indexPath)
        return headerView
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let icon = self.dataSource.item(at: indexPath)
        let iconName = (icon.name == AltIcon.defaultName) ? nil : icon.iconName
        
        guard self.currentAlternateIconName != iconName else { return }
        
        // Optimistically update selected icon name and reload UI so checkmark moves INSTANTLY
        self.currentAlternateIconName = iconName
        collectionView.reloadData()
        
        // If assigning primary icon, pass "nil" as alternate icon name.
        UIApplication.shared.setAlternateIconName(iconName) { [weak self] error in
            DispatchQueue.main.async {
                guard let self = self else { return }
                
                if let error
                {
                    // Revert checkmark if icon change failed
                    self.currentAlternateIconName = UIApplication.shared.alternateIconName
                    self.collectionView.reloadData()
                    
                    let alertController = UIAlertController(title: NSLocalizedString("无法更换应用图标", comment: ""),
                                                            message: error.localizedDescription,
                                                            preferredStyle: .alert)
                    alertController.addAction(.ok)
                    self.present(alertController, animated: true)
                }
                else
                {
                    NotificationCenter.default.post(name: UIApplication.didChangeAppIconNotification, object: icon)
                }
            }
        }
    }
}

