//
//  AppBannerView.swift
//  AltStore
//
//  Created by Riley Testut on 8/29/19.
//  Copyright © 2019 Riley Testut. All rights reserved.
//

@preconcurrency import UIKit

import Nuke

extension AppBannerView
{
    static let standardHeight = 88.0
    
    enum Style
    {
        case app
        case source
    }
    
    enum AppAction
    {
        case install
        case open
        case update
        case custom(String)
    }
}

class AppBannerView: NibView
{
    override var accessibilityLabel: String? {
        get { return self.accessibilityView?.accessibilityLabel }
        set { self.accessibilityView?.accessibilityLabel = newValue }
    }
    
    override open var accessibilityAttributedLabel: NSAttributedString? {
        get { return self.accessibilityView?.accessibilityAttributedLabel }
        set { self.accessibilityView?.accessibilityAttributedLabel = newValue }
    }
    
    override var accessibilityValue: String? {
        get { return self.accessibilityView?.accessibilityValue }
        set { self.accessibilityView?.accessibilityValue = newValue }
    }
    
    override open var accessibilityAttributedValue: NSAttributedString? {
        get { return self.accessibilityView?.accessibilityAttributedValue }
        set { self.accessibilityView?.accessibilityAttributedValue = newValue }
    }
    
    override open var accessibilityTraits: UIAccessibilityTraits {
        get { return self.accessibilityView?.accessibilityTraits ?? [] }
        set { self.accessibilityView?.accessibilityTraits = newValue }
    }
    
    var style: Style = .app
    
    private var originalTintColor: UIColor?
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var subtitleLabel: UILabel!
    @IBOutlet var iconImageView: AppIconImageView!
    @IBOutlet var button: PillButton!
    @IBOutlet var buttonLabel: UILabel!
    @IBOutlet var betaBadgeView: UIView!
    @IBOutlet var sourceIconImageView: AppIconImageView!
    
    @IBOutlet var backgroundEffectView: UIVisualEffectView!
    
    @IBOutlet private var vibrancyView: UIVisualEffectView!
    @IBOutlet private var stackView: UIStackView!
    @IBOutlet private var accessibilityView: UIView!
    
    @IBOutlet private var iconImageViewHeightConstraint: NSLayoutConstraint!
    
    override init(frame: CGRect)
    {
        super.init(frame: frame)
        
        self.initialize()
    }
    
    required init?(coder: NSCoder)
    {
        super.init(coder: coder)
        
        self.initialize()
    }
    
    private func initialize()
    {
        self.accessibilityView.accessibilityTraits.formUnion(.button)
        
        self.isAccessibilityElement = false
        self.accessibilityElements = [self.accessibilityView, self.button].compactMap { $0 }
        
        self.betaBadgeView.isHidden = true
        
        self.sourceIconImageView.style = .circular
        self.sourceIconImageView.isHidden = true
        
        self.layoutMargins = self.stackView.layoutMargins
        self.insetsLayoutMarginsFromSafeArea = false
        
        self.stackView.isLayoutMarginsRelativeArrangement = true
        self.stackView.preservesSuperviewLayoutMargins = true
    }
    
    override func tintColorDidChange()
    {
        super.tintColorDidChange()
        
        if self.tintAdjustmentMode != .dimmed
        {
            self.originalTintColor = self.tintColor
        }
        
        self.update()
    }
}

extension AppBannerView
{
    func configure(for app: AppProtocol, action: AppAction? = nil, showSourceIcon: Bool = true)
    {
        struct AppValues
        {
            var name: String
            var developerName: String? = nil
            var isBeta: Bool = false
            
            init(app: AppProtocol)
            {
                self.name = app.name
                                
                guard let storeApp = (app as? StoreApp) ?? (app as? InstalledApp)?.storeApp else { return }
                self.developerName = storeApp.developerName

                // Determine the beta badge using a fallback chain:
                // 1. For installed apps: use the persisted releaseTrack (the track it was installed from)
                // 2. For store apps / update banners: use latestSupportedVersion.channel
                // 3. If neither is available, assume stable (no badge)
                let track: ReleaseTrackType?
                if let installedApp = app as? InstalledApp {
                    if let persistedTrack = installedApp.releaseTrack?.type {
                        track = persistedTrack
                    } else {
                        track = ReleaseTrackType.from(version: installedApp.version)
                    }
                } else {
                    track = storeApp.latestSupportedVersion?.channel
                }

                if let track, ReleaseTrackType.betaTracks.contains(track)
                {
                    self.name = String(format: NSLocalizedString("%@ 测试版", comment: ""), app.name)
                    self.isBeta = true
                }
            }
        }
        
        self.style = .app

        let values = AppValues(app: app)
        self.titleLabel.text = app.name // Don't use values.name since that already includes "beta".
        self.betaBadgeView.isHidden = !values.isBeta

        if let developerName = values.developerName
        {
            self.subtitleLabel.text = developerName
            self.accessibilityLabel = String(format: NSLocalizedString("%@（作者：%@）", comment: ""), values.name, developerName)
        }
        else
        {
            self.subtitleLabel.text = NSLocalizedString("已侧载", comment: "")
            self.accessibilityLabel = values.name
        }
        self.buttonLabel.isHidden = true
        
        if let source = app.storeApp?.source, showSourceIcon
        {
            self.sourceIconImageView.isHidden = false
            self.sourceIconImageView.backgroundColor = source.effectiveTintColor?.adjustedForDisplay ?? .altPrimary
            
            if let iconURL = source.effectiveIconURL
            {
                if let cached = ImagePipeline.shared.cache[iconURL]
                {
                    self.sourceIconImageView.backgroundColor = .white
                    self.sourceIconImageView.image = cached.image
                }
                else
                {
                    self.sourceIconImageView.image = nil
                    
                    Task { [weak self] in
                        do
                        {
                            let image = try await ImagePipeline.shared.image(for: iconURL)
                            guard let self else { return }
                            self.sourceIconImageView.image = image
                            self.sourceIconImageView.backgroundColor = .white
                        }
                        catch
                        {
                            debugLog("Failed to fetch source icon from \(iconURL). \(error.localizedDescription)")
                        }
                    }
                }
            }
        }
        else
        {
            self.sourceIconImageView.isHidden = true
        }
        
        let buttonAction: AppAction
        
        if let action
        {
            buttonAction = action
        }
        else if let storeApp = app.storeApp
        {
            if let installedApp = storeApp.installedApp
            {
                // App is installed
                
                // if installedApp.isUpdateAvailable
                if installedApp.hasUpdate
                {
                    buttonAction = .update
                }
                else
                {
                    buttonAction = .open
                }
            }
            else
            {
                // App is not installed
                buttonAction = .install
            }
        }
        else
        {
            // App is not from a source, fall back to .open
            buttonAction = .open
        }
        
        UIView.performWithoutAnimation {
            if case .custom = buttonAction {} else {
                self.button.resetDisplayState()
            }
            
            switch buttonAction
            {
            case .open:
                let buttonTitle = NSLocalizedString("打开", comment: "")
                self.button.setTitle(buttonTitle.uppercased(), for: .normal)
                self.button.accessibilityLabel = String(format: NSLocalizedString("打开 %@", comment: ""), values.name)
                self.button.accessibilityValue = buttonTitle
                
                self.button.countdownDate = nil
                
            case .update:
                let buttonTitle = NSLocalizedString("更新", comment: "")
                self.button.setTitle(buttonTitle.uppercased(), for: .normal)
                self.button.accessibilityLabel = String(format: NSLocalizedString("更新 %@", comment: ""), values.name)
                self.button.accessibilityValue = buttonTitle
                
                self.button.countdownDate = nil
                
            case .custom(let buttonTitle):
                self.button.setTitle(buttonTitle, for: .normal)
                self.button.accessibilityLabel = buttonTitle
                self.button.accessibilityValue = buttonTitle
                
                self.button.countdownDate = nil
                
            case .install:
                if let storeApp = app.storeApp, storeApp.isPledgeRequired
                {
                    // Pledge required
                    
                    if storeApp.isPledged
                    {
                        let buttonTitle = NSLocalizedString("安装", comment: "")
                        self.button.setTitle(buttonTitle.uppercased(), for: .normal)
                        self.button.accessibilityLabel = String(format: NSLocalizedString("安装 %@", comment: ""), app.name)
                        self.button.accessibilityValue = buttonTitle
                    }
                    else
                    {
                        let buttonTitle = NSLocalizedString("赞助", comment: "")
                        self.button.setTitle(buttonTitle.uppercased(), for: .normal)
                        self.button.accessibilityLabel = buttonTitle
                        self.button.accessibilityValue = buttonTitle
                    }
                }
                else
                {
                    // Free app
                    
                    let buttonTitle = NSLocalizedString("免费", comment: "")
                    self.button.setTitle(buttonTitle.uppercased(), for: .normal)
                    self.button.accessibilityLabel = String(format: NSLocalizedString("下载 %@", comment: ""), app.name)
                    self.button.accessibilityValue = buttonTitle
                }
                
                if let versionDate = app.storeApp?.latestSupportedVersion?.date, versionDate > Date()
                {
                    self.button.countdownDate = versionDate
                }
                else
                {
                    self.button.countdownDate = nil
                }
            }
            
            // Ensure PillButton is correct size before assigning progress.
            self.layoutIfNeeded()
        }
        
        if let progress = AppManager.shared.installationProgress(for: app), progress.fractionCompleted < 1.0
        {
            self.button.progress = progress
        }
        else
        {
            self.button.progress = nil
        }
    }
    
    func configure(for source: Source)
    {
        self.style = .source
        
        let subtitle: String
        if let text = source.subtitle
        {
            subtitle = text
        }
        else if let scheme = source.sourceURL.scheme
        {
            subtitle = source.sourceURL.absoluteString.replacingOccurrences(of: scheme + "://", with: "")
        }
        else
        {
            subtitle = source.sourceURL.absoluteString
        }
        
        self.titleLabel.text = source.name
        self.subtitleLabel.text = subtitle
        
        let tintColor = source.effectiveTintColor ?? .altPrimary
        self.tintColor = tintColor
        
        let accessibilityLabel = source.name + "\n" + subtitle
        self.accessibilityLabel = accessibilityLabel
    }
}

private extension AppBannerView
{
    func update()
    {
        self.clipsToBounds = true
        self.layer.cornerRadius = 22
        
        let tintColor = self.originalTintColor ?? self.tintColor
        self.subtitleLabel.textColor = tintColor
        
        switch self.style
        {
        case .app:
            self.directionalLayoutMargins.trailing = self.stackView.directionalLayoutMargins.trailing
            
            self.iconImageViewHeightConstraint.constant = 60
            self.iconImageView.style = .icon
            
            self.titleLabel.textColor = .label
            
            self.button.style = .pill
            
            self.backgroundEffectView.contentView.backgroundColor = UIColor(resource: .blurTint)
            self.backgroundEffectView.backgroundColor = tintColor
            
        case .source:
            self.directionalLayoutMargins.trailing = 20
            
            self.iconImageViewHeightConstraint.constant = 44
            self.iconImageView.style = .circular
            
            self.titleLabel.textColor = .white
            
            self.button.style = .custom
            
            self.backgroundEffectView.contentView.backgroundColor = tintColor?.adjustedForDisplay
            self.backgroundEffectView.backgroundColor = nil
            
            #if !os(tvOS)
            if let tintColor, tintColor.isTooBright
            {
                let textVibrancyEffect = UIVibrancyEffect(blurEffect: .init(style: .systemChromeMaterialLight), style: .fill)
                self.vibrancyView.effect = textVibrancyEffect
            }
            else
            {
                // Thinner == more dull
                let textVibrancyEffect = UIVibrancyEffect(blurEffect: .init(style: .systemThinMaterialDark), style: .secondaryLabel)
                self.vibrancyView.effect = textVibrancyEffect
            }
            #else
            let textVibrancyEffect = UIVibrancyEffect(blurEffect: UIBlurEffect(style: .dark))
            self.vibrancyView.effect = textVibrancyEffect
            #endif
        }
    }
}
